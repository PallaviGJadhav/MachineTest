﻿using PagedList;
using PagedList.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TestMachine.Models;
using System.ComponentModel.DataAnnotations;

namespace TestMachine.Controllers
{
    public class HomeController : Controller
    {
        TestDBContext context = new TestDBContext();

        #region Product
        public ActionResult Index(int page = 1)
        {

            IPagedList<ProductMaster> ListOfProduct = null;
            int numberOfRows = 10;
            var categoryList = context.CategoryList.ToList();
            var productList = context.ProductList.ToList();
            ListOfProduct = productList.ToPagedList(page, numberOfRows);
            return View(ListOfProduct);
        }

        [HttpGet]
        public ActionResult Create()
        {
            ViewBag.CategoryList = context.CategoryList.ToList();
            return View();
        }

        [HttpPost]
        public ActionResult Create(ProductMaster product)
        {
            if (ModelState.IsValid)
            {
                context.ProductList.Add(product);
                context.SaveChanges();

                return RedirectToAction("Index");
            }
            ViewBag.CategoryList = context.CategoryList.ToList();
            return View(product);
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            ViewBag.CategoryList = context.CategoryList.ToList();
            var product = context.ProductList.Find(id);
            return View(product);
        }

        [HttpPost]
        public ActionResult Edit(ProductMaster product)
        {
            if (ModelState.IsValid)
            {
                context.Entry(product).State = EntityState.Modified;
                context.SaveChanges();

                return RedirectToAction("Index");
            }
            ViewBag.CategoryList = context.CategoryList.ToList();
            return View(product);
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            ViewBag.CategoryList = context.CategoryList.ToList();
            var product = context.ProductList.Find(id);
            return View(product);
        }

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteProduct(int id)
        {
            if (ModelState.IsValid)
            {
                var product = context.ProductList.Find(id);
                context.ProductList.Remove(product);
                context.SaveChanges();

                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        public ActionResult Details(int id)
        {
            ViewBag.CategoryList = context.CategoryList.ToList();
            var product = context.ProductList.Find(id);
            return View(product);
        }

        #endregion Product

        #region Category
        public ActionResult CategoryList(int page = 1)
        {
            using (var context = new TestDBContext())
            {
                IPagedList<CategoryMaster> ListOfCategory = null;
                int numberOfRows = 10;
                var categoryList = context.CategoryList.ToList();
                ListOfCategory = categoryList.ToPagedList(page, numberOfRows);
                return View(ListOfCategory);
            }
        }

        [HttpGet]
        public ActionResult CreateCategory()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateCategory(CategoryMaster category)
        {
            if (ModelState.IsValid)
            {
                context.CategoryList.Add(category);
                context.SaveChanges();
                return RedirectToAction("CategoryList");
            }
            return View(category);
        }

        [HttpGet]
        public ActionResult EditCategory(int id)
        {
            ViewBag.CategoryList = context.CategoryList.ToList();
            var category = context.CategoryList.Find(id);
            return View(category);
        }

        [HttpPost]
        public ActionResult EditCategory(CategoryMaster category)
        {
            if (ModelState.IsValid)
            {
                context.Entry(category).State = EntityState.Modified;
                context.SaveChanges();

                return RedirectToAction("CategoryList");
            }
            return View(category);
        }


        [HttpGet]
        public ActionResult DeleteCategory(int id)
        {
            var category = context.CategoryList.Find(id);
            return View(category);
        }

        [HttpPost, ActionName("DeleteCategory")]
        public ActionResult DeleteProductCategory(int id)
        {
            if (ModelState.IsValid)
            {
                var category = context.CategoryList.Find(id);
                context.CategoryList.Remove(category);
                context.SaveChanges();

                return RedirectToAction("CategoryList");
            }
            return View();
        }
        #endregion Product
    }
}
