﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace TestMachine.Models
{
    public class CategoryMaster
    {
        [Key]
        public int CategoryId { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 3)]
        public string CategoryName { get; set; }

        [InverseProperty("ProductCategory")]
        public ICollection<ProductMaster> ProductList { get; set; }
    }
}