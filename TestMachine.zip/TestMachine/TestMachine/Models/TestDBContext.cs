﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace TestMachine.Models
{
    public class TestDBContext : DbContext
    {
        public TestDBContext() : base("TestDBContext")
        {
        
        }

        public DbSet<ProductMaster> ProductList { get; set; }
        public DbSet<CategoryMaster> CategoryList { get; set; }

    }
}