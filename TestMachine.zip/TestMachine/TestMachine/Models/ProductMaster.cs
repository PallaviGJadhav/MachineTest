﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace TestMachine.Models
{
    public class ProductMaster
    {
        [Key]
        public int ProductId { get; set; }

        [Required(ErrorMessage="Please Enter Product Name")]
        [StringLength(100, MinimumLength = 3)]
        public string ProductName { get; set; }

        [ForeignKey("ProductCategory")]
        public int? ProductCategoryId { get; set; }
        public CategoryMaster ProductCategory { get; set; }
    }
}